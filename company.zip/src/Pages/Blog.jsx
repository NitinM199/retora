import React, { useEffect } from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { Link } from 'react-router-dom'
import { Blogfetch, Catagoryfetch, Rpostfetch } from '../redux/AllSlice'
import Layout from '../common/Layout/Layout'
import Spiner from '../Spinner/Spiner'


const Blog = () => {


  const {Blog,Catagory,recentpostsata} = useSelector((state)=>{
    return state.valuedata
  })
  const url = "https://restapinodejs.onrender.com/api/blogdetails/"
  const dispatch = useDispatch()
  useEffect(()=>{
    dispatch(Blogfetch())
    dispatch(Catagoryfetch())
    dispatch(Rpostfetch())
  },[dispatch])
  console.log("Blog",Blog);
  console.log("catagory",Catagory);
  console.log("post",recentpostsata);
 
  if (!Blog || !Catagory || !recentpostsata) {
    return <Spiner/>;
  }

  return (
    <>
    
    <Layout>
    <main id="main">
  {/* ======= Breadcrumbs ======= */}
  <section id="breadcrumbs" className="breadcrumbs">
    <div className="container my-4">
      <div className="d-flex justify-content-between align-items-center">
        <h2>Blog</h2>
        <ol>
        <li><Link to="/">Home</Link></li>
          <li>Blog</li>
        </ol>
      </div>
    </div>
  </section>{/* End Breadcrumbs */}
  {/* ======= Blog Section ======= */}
  <section id="blog" className="blog">
    <div className="container">
      <div className="row">
        <div className="col-lg-8 entries">

          {
            Blog?.map((item)=>{
              return (
                <>
                
          <article className="entry" data-aos="fade-up">
            <div className="entry-img">
              <img src={`https://restapinodejs.onrender.com/api/blog/image/${item._id}`} alt className="img-fluid" />
            </div>
            <h2 className="entry-title">
              <a href="blog-single.html">{item.title}</a>
            </h2>
            <div className="entry-meta">
              <ul>
                <li className="d-flex align-items-center"><i className="icofont-user" /> <a href="blog-single.html">John Doe</a></li>
                <li className="d-flex align-items-center"><i className="icofont-wall-clock" /> <a href="blog-single.html"><time dateTime="2020-01-01">Jan 1, 2020</time></a></li>
                <li className="d-flex align-items-center"><i className="icofont-comment" /> <a href="blog-single.html">12 Comments</a></li>
              </ul>
            </div>
            <div className="entry-content">
            <p dangerouslySetInnerHTML={{
                                    __html: item?.postText&&item?.postText.slice(0,400)
                                }}></p>
              <div className="read-more">
                <Link to={`/blogdetails/${item._id}`}>Read More</Link>
              </div>
            </div>
          </article>
                
                </>
              )
            })
          }

         
          
        
          <div className="blog-pagination">
            <ul className="justify-content-center">
              <li className="disabled"><i className="icofont-rounded-left" /></li>
              <li><a href="#">1</a></li>
              <li className="active"><a href="#">2</a></li>
              <li><a href="#">3</a></li>
              <li><a href="#"><i className="icofont-rounded-right" /></a></li>
            </ul>
          </div>
        </div>
       
        <div className="col-lg-4">
          <div className="sidebar" data-aos="fade-left">
            <h3 className="sidebar-title">Search</h3>
            <div className="sidebar-item search-form">
              <form action>
                <input type="text" />
                <button type="submit"><i className="icofont-search" /></button>
              </form>
            </div>{/* End sidebar search formn*/}
            <h3 className="sidebar-title">Categories</h3>
            <div className="sidebar-item categories">
              <ul>
                {
                  Catagory?.map((item)=>{
                    return(
                      <>
                      <li><Link to={`/catagory/${item._id}`}>{item.category}<span>(25)</span></Link></li>
                      
                      </>
                    )
                  })
                }
               
              </ul>
            </div>{/* End sidebar categories*/}
            <h3 className="sidebar-title">Recent Posts</h3>
            <div className="sidebar-item recent-posts">


              {
                  recentpostsata?.map((item)=>{
                    const [date] =
                      item.createdAt.split("T");
                    return(
                      <>
                      
                      <div className="post-item clearfix">
                        <img src={`https://restapinodejs.onrender.com/api/blog/image/${item._id}`} alt />
                        <h4><Link to="/blogsingle">{item.title}</Link></h4>
                        <time dateTime="2020-01-01">{date}</time>
                      </div>
                      </>
                    )
                  })
              }
              



            </div>{/* End sidebar recent posts*/}
          </div>{/* End sidebar */}
        </div>{/* End blog sidebar */}
      </div>
    </div> 
  </section>{/* End Blog Section */}
</main>
</Layout>
    </>
  )
}

export default Blog