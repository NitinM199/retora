import React, { useEffect, useState }  from 'react'
import Layout from '../common/Layout/Layout'
import { useDispatch, useSelector } from 'react-redux'
import { Link, useParams } from 'react-router-dom'
import { Catagoryfetch, Commentsfecth, Getcommentfecth, Rpostfetch, Singleblogdata } from '../redux/AllSlice'



const Singleblog = () => {
  const {id}= useParams()

  
  const {singleb,Catagory,recentpostsata,getcomment}=useSelector((state)=>{
    return state.valuedata
  })
  const dispatch = useDispatch()
  const initialValues = {
    name: '',
    email: '',
    comment: '',
    blog: id
  }
  const [comment,setComment]=useState(initialValues)
const Commentsubmit=(e)=>{
  e.preventDefault()
  alert("comment register")
 dispatch(Commentsfecth(comment))
 setComment(initialValues)
}

const commentchange=(e)=>{
  const {name,value}=e.target
  setComment({...comment,[name]:value})
  console.log(comment);
}

  useEffect(()=>{
    dispatch(Singleblogdata(id))
    dispatch(Catagoryfetch())
    dispatch(Rpostfetch())
    dispatch(Getcommentfecth(id))
  },[dispatch,id])
  
console.log(singleb);
console.log("getcomment",getcomment);
  return (
    <>
  <Layout>
 <main id="main">
  {/* ======= Breadcrumbs ======= */}
  <section id="breadcrumbs" className="breadcrumbs">
    <div className="container">
      <div className="d-flex justify-content-between align-items-center">
        <h2>Blog</h2>
        <ol>
          <li><a href="index.html">Home</a></li>
          <li>Blog</li>
        </ol>
      </div>
    </div>
  </section>
 
  <section id="blog" className="blog">
    <div className="container">
      <div className="row">
        <div className="col-lg-8 entries">
                
                <article className="entry entry-single" data-aos="fade-up">
                  <div className="entry-img">
                  <img src={`https://restapinodejs.onrender.com/api/blog/image/${singleb._id}`} alt="" class="img-fluid" />
                  </div>
                  <h2 className="entry-title">
                  <a href="blog-single.html">{singleb?.title}</a>
                  </h2>
                  <div className="entry-meta">
                    <ul>
                      <li className="d-flex align-items-center"><i className="icofont-user" /> <a href="blog-single.html">John Doe</a></li>
                      <li className="d-flex align-items-center"><i className="icofont-wall-clock" /> <a href="blog-single.html"><time dateTime="2020-01-01">Jan 1, 2020</time></a></li>
                      <li className="d-flex align-items-center"><i className="icofont-comment" /> <a href="blog-single.html">12 Comments</a></li>
                    </ul>
                  </div>
                  <div className="entry-content">
                  
                  <p dangerouslySetInnerHTML={{
                                    __html: singleb?.postText
                                }}></p>
                  </div>
                  <div className="entry-footer clearfix">
                    <div className="float-left">
                      <i className="icofont-folder" />
                      <ul className="cats">
                        <li><a href="#">Business</a></li>
                      </ul>
                      <i className="icofont-tags" />
                      <ul className="tags">
                        <li><a href="#">Creative</a></li>
                        <li><a href="#">Tips</a></li>
                        <li><a href="#">Marketing</a></li>
                      </ul>
                    </div>
                    <div className="float-right share">
                      <a href title="Share on Twitter"><i className="icofont-twitter" /></a>
                      <a href title="Share on Facebook"><i className="icofont-facebook" /></a>
                      <a href title="Share on Instagram"><i className="icofont-instagram" /></a>
                    </div>
                  </div>
                </article>
                

          {/* blog comments.................................. */}
          <div className="blog-comments" data-aos="fade-up">
            <h4 className="comments-count">Comments ({getcomment?.length})</h4>
            {
              getcomment?.map?.((item)=>{
                return(
                  <>
                   <div id="comment-1" className="comment clearfix">
              <h5 ><a style={{color:"green"}}href>{item.name}</a> </h5>
              <time dateTime="2020-01-01">{new Date(item.createdAt).toLocaleDateString()}</time>
              <p>
               {item.comment}
              </p>
            </div>
                  
                  </>
                )
              })
            }
           
            {/* End comment #1 */}


            
            <div className="reply-form">
              <h4>Leave a Reply</h4>
              <p>Your email address will not be published. Required fields are marked * </p>
              <form onSubmit={Commentsubmit} action>
                <div className="row">
                  <div className="col-md-6 form-group">
                    <input name="name" value={comment.name} onChange={commentchange} type="text" className="form-control" placeholder="Your Name*" />
                  </div>
                  <div className="col-md-6 form-group">
                    <input name="email" value={comment.email} onChange={commentchange} type="text" className="form-control" placeholder="Your Email*" />
                  </div>
                </div>
                
                <div className="row">
                  <div className="col form-group">
                    <textarea name="comment" value={comment.comment} onChange={commentchange} className="form-control" placeholder="Your Comment*" defaultValue={""} />
                  </div>
                </div>
                <button type="submit" className="btn btn-primary">Post Comment</button>
              </form>
            </div>


          </div>
          
          {/* End blog comments */}








        </div>{/* End blog entries list */}
        <div className="col-lg-4">
          <div className="sidebar" data-aos="fade-left">
            <h3 className="sidebar-title">Search</h3>
            <div className="sidebar-item search-form">
              <form action>
                <input type="text" />
                <button type="submit"><i className="icofont-search" /></button>
              </form>
            </div>{/* End sidebar search formn*/}
            <h3 className="sidebar-title">Categories</h3>
            <div className="sidebar-item categories">
              <ul>
              {
                  Catagory?.map((item)=>{
                    return(
                      <>
                      <li><Link to={`/catagory/${item._id}`}>{item.category}<span>(25)</span></Link></li>
                      
                      </>
                    )
                  })
                }
              </ul>
            </div>{/* End sidebar categories*/}
            <h3 className="sidebar-title">Recent Posts</h3>
            <div className="sidebar-item recent-posts">
            {
                  recentpostsata?.map((item)=>{
                    const [date] =
                      item.createdAt.split("T");
                    return(
                      <>
                      
                      <div className="post-item clearfix">
                        <img src={`https://restapinodejs.onrender.com/api/blog/image/${item._id}`} alt />
                        <h4><Link to="/blogsingle">{item.title}</Link></h4>
                        <time dateTime="2020-01-01">{date}</time>
                      </div>
                      </>
                    )
                  })
              }
              
            </div>
            
            {/* End sidebar recent posts*/}
          </div>{/* End sidebar */}
        </div>{/* End blog sidebar */}
      </div>
    </div>
  </section>
  {/* End Blog Section */}
</main>




</Layout>

      
    
    </>
  )
}

export default Singleblog