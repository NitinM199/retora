import React, { useEffect } from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { Bannerfetch, Servicefech, Testimonialfetch } from '../redux/AllSlice'
import Layout from '../common/Layout/Layout'

const Home = () => {
  const {value,bannerdata,testimonial_value,} = useSelector((state)=>{
    return state.valuedata
  })
  const dispatch = useDispatch()
  
  useEffect(()=>{
    dispatch(Servicefech())
    dispatch(Bannerfetch())
    dispatch(Testimonialfetch())
  },[dispatch])
  console.log("services",value);
  console.log("banner",bannerdata);
  console.log("testimonial",testimonial_value);
  return (
  <>
  <Layout>
    {/* Navbar start............................................................................................................. */}
    <section id="hero">
    <div id="heroCarousel" className="carousel slide carousel-fade" data-ride="carousel">
    <div className="carousel-inner" role="listbox">

        {
          bannerdata?.map((item,key)=>{
            return(
              <> 
               {
                key === 0 ? (
                    <>
                        <div class="carousel-item active"
                         style={{ backgroundImage: `url(https://restapinodejs.onrender.com/api/banner/photo/${item._id})`}} 
                         key={key}>
                            <div class="carousel-container">
                                <div class="carousel-content animate__animated animate__fadeInUp">
                                    <h2>{item.title}</h2>
                                    <p>{item.description}</p>
                                    <div class="text-center"><a href="" class="btn-get-started">Read More</a></div>
                                </div>
                            </div>
                        </div>
                    </>
                    ) : (
                        <>
                            <div class="carousel-item" style={{ backgroundImage: `url(https://restapinodejs.onrender.com/api/banner/photo/${item._id})` }} key={key}>
                                <div class="carousel-container">
                                    <div class="carousel-content animate__animated animate__fadeInUp">
                                        <h2>{item.title}</h2>
                                        <p>{item.description}</p>
                                        <div class="text-center"><a href="" class="btn-get-started">Read More</a></div>
                                    </div>
                                </div>
                            </div>
                        </>
                    )
                }
              </>
            )
          })
        }

      
    </div>


    <a className="carousel-control-prev" href="#heroCarousel" role="button" data-slide="prev">
        <span className="carousel-control-prev-icon icofont-simple-left" aria-hidden="true" />
        <span className="sr-only">Previous</span>
    </a>
    <a className="carousel-control-next" href="#heroCarousel" role="button" data-slide="next">
        <span className="carousel-control-next-icon icofont-simple-right" aria-hidden="true" />
        <span className="sr-only">Next</span>
    </a>
    <ol className="carousel-indicators" id="hero-carousel-indicators" />
    </div>

    </section>

    {/* Navbar end............................................................................................................. */}

    {/* About start............................................................................................................. */}
    <section id="about-us" className="about-us">
    <div className="container" data-aos="fade-up">
        <div className="section-title">
        <h2>About Us</h2>
        </div>
        <div className="row content">
        <div className="col-lg-6" data-aos="fade-right">
            <h2>Eum ipsam laborum deleniti velitena</h2>
            <h3>Voluptatem dignissimos provident quasi corporis voluptates sit assum perenda sruen jonee trave</h3>
        </div>
        <div className="col-lg-6 pt-4 pt-lg-0" data-aos="fade-left">
            <p>
            Ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate
            velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in
            culpa qui officia deserunt mollit anim id est laborum
            </p>
            <ul>
            <li><i className="ri-check-double-line" /> Ullamco laboris nisi ut aliquip ex ea commodo consequa</li>
            <li><i className="ri-check-double-line" /> Duis aute irure dolor in reprehenderit in voluptate velit</li>
            <li><i className="ri-check-double-line" /> Ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in</li>
            </ul>
            <p className="font-italic">
            Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore
            magna aliqua.
            </p>
        </div>
        </div>
    </div>
    </section>

    {/* About end............................................................................................................. */}
    {/* Services start............................................................................................................. */}

    <section id="services" className="services section-bg">
    <div className="container" data-aos="fade-up">
        <div className="section-title">
        <h2>Services</h2>
        <p>Laborum repudiandae omnis voluptatum consequatur mollitia ea est voluptas ut</p>
        </div>
        <div className="row">
       {
        value?.map?.((item)=>{
          return(
            <>
             <div className="col-lg-4 col-md-6 d-flex align-items-stretch p-3" data-aos="zoom-in" data-aos-delay={100}>
            <div className="icon-box iconbox-blue">
            <div className="icon">
                <svg width={100} height={100} viewBox="0 0 600 600" xmlns="http://www.w3.org/2000/svg">
                <path stroke="none" strokeWidth={0} fill="#f5f5f5" d="M300,521.0016835830174C376.1290562159157,517.8887921683347,466.0731472004068,529.7835943286574,510.70327084640275,468.03025145048787C554.3714126377745,407.6079735673963,508.03601936045806,328.9844924480964,491.2728898941984,256.3432110539036C474.5976632858925,184.082847569629,479.9380746630129,96.60480741107993,416.23090153303,58.64404602377083C348.86323505073057,18.502131276798302,261.93793281208167,40.57373210992963,193.5410806939664,78.93577620505333C130.42746243093433,114.334589627462,98.30271207620316,179.96522072025542,76.75703585869454,249.04625023123273C51.97151888228291,328.5150500222984,13.704378332031375,421.85034740162234,66.52175969318436,486.19268352777647C119.04800174914682,550.1803526380478,217.28368757567262,524.383925680826,300,521.0016835830174" />
                </svg>
                <i className="bx bxl-dribbble" />
            </div>
            <h4><a href>{item.name}</a></h4>
            <p>{item.details && item.details.slice(0,55)}</p>
            </div>
        </div>      
            </>
          )
        })
       }
       
        </div>
    </div>
    </section>

    {/* Services end............................................................................................................. */}
    {/* Testimonial start............................................................................................................. */}

    <section id="testimonials" className="testimonials section-bg">
    <div className="container">
        <div className="section-title">
        <h2>Testimonials</h2>
        <p>Laborum repudiandae omnis voluptatum consequatur mollitia ea est voluptas ut</p>
        </div>
        <div className="row">

        {
                testimonial_value?.map?.((item)=>{
                    return (
                        <>
                        
        <div className="col-lg-6 p-3" data-aos="fade-up">
            <div className="testimonial-item">
            <img src={`https://restapinodejs.onrender.com/api/testimonials/photo/${item._id}`} className="testimonial-img" alt />
            <h3>{item.name}</h3>
            <h4>{item.position}</h4>
            <p>
                <i className="bx bxs-quote-alt-left quote-icon-left" />
                {item.talk&&item.talk.slice(0,70)}
                <i className="bx bxs-quote-alt-right quote-icon-right" />
            </p>
            </div>
        </div>

                        </>
                    )
                })
        }


      

        </div>
    </div>
    </section>

    {/* Testimonial end............................................................................................................. */}
    {/* Our Client Start............................................................................................................. */}

    <section id="clients" className="clients">
    <div className="container" data-aos="fade-up">
        <div className="section-title">
        <h2>Companys </h2>
        </div>
        <div className="row no-gutters clients-wrap clearfix" data-aos="fade-up">
        <div className="col-lg-3 col-md-4 col-6">
            <div className="client-logo">
            <img src="assets/img/clients/client-1.png" className="img-fluid" alt />
            </div>
        </div>
        <div className="col-lg-3 col-md-4 col-6">
            <div className="client-logo">
            <img src="assets/img/clients/client-2.png" className="img-fluid" alt />
            </div>
        </div>
        <div className="col-lg-3 col-md-4 col-6">
            <div className="client-logo">
            <img src="assets/img/clients/client-3.png" className="img-fluid" alt />
            </div>
        </div>
        <div className="col-lg-3 col-md-4 col-6">
            <div className="client-logo">
            <img src="assets/img/clients/client-4.png" className="img-fluid" alt />
            </div>
        </div>
        <div className="col-lg-3 col-md-4 col-6">
            <div className="client-logo">
            <img src="assets/img/clients/client-5.png" className="img-fluid" alt />
            </div>
        </div>
        <div className="col-lg-3 col-md-4 col-6">
            <div className="client-logo">
            <img src="assets/img/clients/client-6.png" className="img-fluid" alt />
            </div>
        </div>
        <div className="col-lg-3 col-md-4 col-6">
            <div className="client-logo">
            <img src="assets/img/clients/client-7.png" className="img-fluid" alt />
            </div>
        </div>
        <div className="col-lg-3 col-md-4 col-6">
            <div className="client-logo">
            <img src="assets/img/clients/client-8.png" className="img-fluid" alt />
            </div>
        </div>
        </div>
    </div>
    </section>

    {/* Our Client end............................................................................................................. */}
    </Layout>
  </>
  )
}

export default Home