import React from 'react'
import { useState } from 'react'
import { useDispatch } from 'react-redux'
import { Applycourseapi } from '../redux/AllSlice'
import { useParams } from 'react-router-dom'

const Applycourse = () => {
   
    const { course,id } = useParams()
    const initialState = {
        course: id,
        course_name: course,
        name: '',
        email: '',
        phone: '',
        city: '',
        address: '',
        qualification: '',
        programing_knowledge: '',
        experiance: ''
    }
    const [Apply,setApply]=useState(initialState)
    const dispatch = useDispatch()
    const Handelsubmit = (e)=>{
        e.preventDefault();
        alert("submit Succesfully")
        dispatch(Applycourseapi(Apply))
    }
    const Handelchange = (e)=>{
        const{name,value}=e.target
        setApply({...Apply,[name]:value})
        console.log(Apply);
    }
  return (
    <>
    
    
    <section id="contact" class="contact">
            <div class="container">

                <div class="row justify-content-center" data-aos="fade-up">

                    <div class="col-lg-10">

                        <div class="info-wrap">
                            <div class="row">
                                <div class="info">
                                    <h4>Apply for course</h4>
                                    <p>Fill the following form to apply for the course.</p>
                                </div>


                            </div>
                        </div>

                    </div>

                </div>

                <div class="row mt-5 justify-content-center" data-aos="fade-up">
                    <div class="col-lg-10">
                        <form onSubmit={Handelsubmit}  role="form" class="php-email-form">

                            <div class="form-group">
                                <input type="text" class="form-control" name="name" id="name" placeholder="Your Full name" data-rule="name" data-msg="Please enter your name"
                                    value={Apply.name}
                                    onChange={Handelchange} />
                               
                            </div>

                            <div class="form-group">
                                <input type="email" class="form-control" name="email" id="email" placeholder="Your Email" data-rule="email" data-msg="Please enter a valid email"
                                    value={Apply.email}
                                    onChange={Handelchange} />
                              
                            </div>

                            <div class="form-group">
                                <input type="text" class="form-control" name="phone" id="phone" placeholder="Your phone number" data-rule="name" data-msg="Please enter your name"
                                    value={Apply.phone}
                                    onChange={Handelchange} />
                               
                            </div>

                            <div class="form-group">
                                <input type="text" class="form-control" name="address" id="address" placeholder="Your Address" data-rule="name" data-msg="Please enter your name"
                                    value={Apply.address}
                                    onChange={Handelchange} />
                                
                            </div>

                            <div class="form-group">
                                <input type="text" class="form-control" name="city" id="city" placeholder="Your City" data-rule="name" data-msg="Please enter your name"
                                    value={Apply.city}
                                    onChange={Handelchange} />
                                
                            </div>

                            <div class="form-group">
                                <textarea class="form-control" name="qualification" id='qualification' rows="3" data-rule="qualification" data-msg="Provide your qualification" placeholder="Qualification"
                                    value={Apply.qualification}
                                    onChange={Handelchange} ></textarea>
                                
                            </div>

                            <div class="form-group">
                                <textarea class="form-control" name="programing_knowledge" id='programing_knowledge' rows="3" data-rule="programing_knowledge" data-msg="Provide your programming knowledge" placeholder="Programming knowledge"
                                    value={Apply.programing_knowledge}
                                    onChange={Handelchange} ></textarea>
                                
                            </div>

                            <div class="form-group">
                                <textarea class="form-control" name="experiance" id='experiance' rows="3" data-rule="experiance" data-msg="Provide your experiance" placeholder="Experiance"
                                    value={Apply.experiance}
                                    onChange={Handelchange} ></textarea>
                                
                            </div>

                            <div class="text-center"><button type="submit">Apply Now</button></div>
                        </form>
                    </div>

                </div>

            </div>
        </section>
    
    
    </>
  )
}

export default Applycourse