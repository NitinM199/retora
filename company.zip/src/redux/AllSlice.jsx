import { createAsyncThunk, createSlice } from "@reduxjs/toolkit"
import axios from "axios"

const serviceurl = "https://restapinodejs.onrender.com/api/service"
const Bannerurl = "https://restapinodejs.onrender.com/api/banner"
// const imageUrl = "https://restapinodejs.onrender.com/api/banner/photo/"
const testimonialUrl  = "https://restapinodejs.onrender.com/api/testimonial"
const Courseurl = "https://restapinodejs.onrender.com/api/course"
const Teamurl = "https://restapinodejs.onrender.com/api/team"
const Blogurl = "https://restapinodejs.onrender.com/api/allBlog"
const Catagoryurl = "https://restapinodejs.onrender.com/api/showallcategory"
const Resentposturl = "https://restapinodejs.onrender.com/api/letest-post"
const Registrationapi = "https://restapinodejs.onrender.com/api/register"
const loging = "https://restapinodejs.onrender.com/api/login"
const Contacturl = "https://restapinodejs.onrender.com/api/contact/create"


export const RegtistionApi = createAsyncThunk("RegtistionApi",async(Userdata)=>{
   try {
    const res = await axios.post(Registrationapi,Userdata)

    return res?.data
   } catch (error) {
    return error.res?.data
   }
})

export const logingapiApi = createAsyncThunk("logingapiApi",async(userlog)=>{
    try {
     const respons = await axios.post(loging,userlog)
 
     return respons?.data
    } catch (error) {
     return error.res?.data
    }
})


export const Servicefech = createAsyncThunk("fechdata",async()=>{
    try{
        const res = await axios.get(serviceurl)
        return res?.data?.data
    }
    catch(err){
        console.log(err);
    }
})

export const Bannerfetch = createAsyncThunk("fechbanner",async()=>{
    try{
        const res = await axios.get(Bannerurl)
        return res?.data
    }
    catch(err){
        console.log(err);
    }
})

export const Testimonialfetch = createAsyncThunk("Testimonialfetch",async()=>{
    try{
        const res = await axios.get(testimonialUrl)
        return res?.data?.testimonials
    }
    catch(err){
        console.log(err);
    }
})

export const Coursefetch = createAsyncThunk("Coursefetch",async()=>{
    try{
        const res = await axios.get(Courseurl)
        return res?.data?.Courses
    }
    catch(err){
        console.log(err);
    }
})

export const Teamfetch = createAsyncThunk("Teamfetch",async()=>{
    try{
        const res = await axios.get(Teamurl)
        return res?.data?.TeamMember
    }
    catch(err){
        console.log(err);
    }
})

export const Blogfetch = createAsyncThunk("Blogfetch",async()=>{
    try{
        const res = await axios.get(Blogurl)
        return res?.data?.data
    }
    catch(err){
        console.log(err);
    }
})

export const Catagoryfetch = createAsyncThunk("Catagoryfetch",async()=>{
    try{
        const res = await axios.get(Catagoryurl)
        return res?.data?.data
    }
    catch(err){
        console.log(err);
    }
})

export const Rpostfetch = createAsyncThunk("Rpostfetch",async()=>{
    try{
        const res = await axios.get(Resentposturl)
        return res?.data?.data
    }
    catch(err){
        console.log(err);
    }
})

export const Singleblogdata = createAsyncThunk("Singleblog",async(id)=>{
    try{
        const res = await axios.get(`https://restapinodejs.onrender.com/api/blogdetails/${id}`)
        return res?.data?.data
    }
    catch(err){
        console.log(err);
    }
})

export const Commentsfecth = createAsyncThunk("Commentsfecth",async(data)=>{
    try{
        const res = await axios.post(`https://restapinodejs.onrender.com/api/blog/${data.blog}/comment/create`,data)
        return res?.data
    }
    catch(err){
        console.log(err);
    }
})

export const Getcommentfecth = createAsyncThunk("Getcommentfecth",async(PostItem)=>{
    try{
        const res = await axios.get(`https://restapinodejs.onrender.com/api/comment/${PostItem}`)
        return res?.data?.post?.comment?.comments
    }
    catch(err){
        console.log(err);
    }
})

export const Applycourseapi = createAsyncThunk("Applycourseapi",async(data)=>{
    try{
        const response = await axios.post(`https://restapinodejs.onrender.com/api/course/apply/${data.course}`,data)
        return response
    }
    catch(err){
        console.log(err);
    }
})

export const Contactfectapi = createAsyncThunk("Contactfectapi",async(data)=>{
    try{
        const response = await axios.post(Contacturl,data)
        return response?.data
    }
    catch(err){
        console.log(err);
    }
})

const initialState = {
    isSucces : '',
    value : [],
    bannerdata :[],
    status : 'idle',
    testimonial_value : [],
    course : [],
    team : [],
    Blog : [],
    Catagory : [],
    recentpostsata : [],
    singleb : [],
    error : "",
    comments: [],
    getcomment : [],
    regdata : [],
    logdata:[],
    isLogging : false,
    coursedata:[],
    contactdata: [],

}

export const Slicedata = createSlice({
    name : "name",
    initialState,
    reducers : {

    },
    extraReducers:{
        //services
        [Servicefech.pending]:(state)=>{
            state.isSucces = "loading"

        },
        [Servicefech.fulfilled]:(state,{payload})=>{
            state.value = payload
        },
        [Servicefech.rejected]:(state)=>{
            state.error = "errror"
        },

        //banner
        [Bannerfetch.pending]:(state)=>{
            state.isSucces = "loading"

        },
        [Bannerfetch.fulfilled]:(state,{payload})=>{
           if(payload.success){
            state.status = "success"
            state.bannerdata = payload.bannerdata
           }
        },
        [Bannerfetch.rejected]:(state)=>{
            state.error = "errror"
        },

         //testimonial
         [Testimonialfetch.pending]:(state)=>{
            state.isSucces = "loading"
        },
        [Testimonialfetch.fulfilled]:(state,{payload})=>{
            state.testimonial_value = payload
        },
        [Testimonialfetch.rejected]:(state)=>{
            state.error = "errror"
        },

         //course....
         [Coursefetch.pending]:(state)=>{
            state.isSucces = "loading"
        },
        [Coursefetch.fulfilled]:(state,{payload})=>{
            state.course = payload
        },
        [Coursefetch.rejected]:(state)=>{
            state.error = "error"
        },

        //Tearm....
        [Teamfetch.pending]:(state)=>{
            state.isSucces = "loading"
        },
        [Teamfetch.fulfilled]:(state,{payload})=>{
            state.team = payload
        },
        [Teamfetch.rejected]:(state)=>{
            state.error = "error"
        },

        //blog.......................
        [Blogfetch.pending]:(state)=>{
            state.isSucces = "loading"
        },
        [Blogfetch.fulfilled]:(state,{payload})=>{
            state.Blog = payload
        },
        [Blogfetch.rejected]:(state)=>{
            state.error = "error"
        },

        //catagory...........
        [Catagoryfetch.pending]:(state)=>{
            state.isSucces = "loading"
        },
        [Catagoryfetch.fulfilled]:(state,{payload})=>{
            state.Catagory = payload
        },
        [Catagoryfetch.rejected]:(state)=>{
            state.error = "error"
        },

         //postdata...........
         [Rpostfetch.pending]:(state)=>{
            state.isSucces = "loading"
        },
        [Rpostfetch.fulfilled]:(state,{payload})=>{
            state.recentpostsata = payload
        },
        [Rpostfetch.rejected]:(state)=>{
            state.error = "error"
        },

  ///registration
        [RegtistionApi.pending]:(state)=>{
            state.isSucces = "loading"
        },
        [RegtistionApi.fulfilled]:(state,{payload})=>{
            state.regdata = payload
        },
        [RegtistionApi.rejected]:(state)=>{
            state.error = "error"
        },

     //singleblog
     [Singleblogdata.pending]:(state)=>{
        state.isSucces = "loading"
    },
    [Singleblogdata.fulfilled]:(state,{payload})=>{
        state.singleb = payload
    },
    [Singleblogdata.rejected]:(state)=>{
        state.error = "error"
    },
     
    //comment post data
    [Commentsfecth.pending]: (state) => {
        state.comments = 'loading'
    },
    [Commentsfecth.fulfilled]: (state, { payload }) => {
            state.comments = payload      
    },
    [Commentsfecth.rejected]: (state) => {
        state.comments = 'failed'
    },

    //comment get api 
    [Getcommentfecth.pending]: (state) => {
        state.getcomment = 'loading'
    },
    [Getcommentfecth.fulfilled]: (state, { payload }) => {
        state.getcomment = payload   
    },
    [Getcommentfecth.rejected]: (state) => {
        state.getcomment = 'failed'
    },

    //logingdata 
    [logingapiApi.pending]:(state)=>{
        state.isSucces = "loading"
    },
    [logingapiApi.fulfilled]:(state,{payload})=>{
        state.logdata = payload
    },
    [logingapiApi.rejected]:(state)=>{
        state.error = "error"
    },
    //apply course....
    [Applycourseapi.pending]:(state)=>{
        state.isSucces = "loading"
    },
    [Applycourseapi.fulfilled]:(state,action)=>{
        state.contactdata = action.payload;
    },
    [Applycourseapi.rejected]:(state)=>{
        state.error = "error"
    },
    //contact post

    [Contactfectapi.pending]:(state)=>{
        state.isSucces = "loading"
    },
    [Contactfectapi.fulfilled]:(state,action)=>{
        state.contactdata = action.payload
    },
    [Contactfectapi.rejected]:(state)=>{
        state.error = "error"
    },


}
})

export default Slicedata.reducer