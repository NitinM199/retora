import { configureStore } from "@reduxjs/toolkit";
import { Slicedata } from "./AllSlice";

export const Mydata = configureStore({
    reducer:{
        valuedata : Slicedata.reducer,
        
    }
})
