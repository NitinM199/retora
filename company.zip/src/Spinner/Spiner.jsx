import React from 'react'
import '../Spinner/Spinner.css'
const Spiner = () => {
  return (
   <>
   <span class="loader"></span>
   </>
  )
}

export default Spiner