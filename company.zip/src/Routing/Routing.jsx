import React from 'react'
import { Routes,Route } from 'react-router-dom';
import Home from '../Pages/Home';
import About from '../Pages/About';
import Courses from '../Pages/Courses';
import Blog from '../Pages/Blog';
import Contact from '../Pages/Contact';
import Singleblog from '../Pages/Singleblog';
import Loging from '../Pages/Auth/Loging'

import Register from '../Pages/Auth/Register';
import Applycourse from '../Pages/Applycourse';
const Routing = () => {
  const Publicelement = [
    {
    path : "/resgister",
    component : <Register/>
  },

  {
    path : "/loging",
    component : <Loging/>
  }

]

const privaterouter = [
  {
    path : "/",
    component : <Home/>
  },
  {
    path : "/about",
    component : <About/>
  },
  {
    path : "/courses",
    component : <Courses/>
  },

  {
    path : "/apply/:course/:id",
    component : <Applycourse/>
  },
  {
    path : "/Blog",
    component : <Blog/>
  },
  {
    path : "/catagory/:id",
    component : <Blog/>
  },
  {
    path : "/contact",
    component : <Contact/>
  },
  {
    path : "/blogdetails/:id",
    component : <Singleblog/>
  },

 
  
]
  return (
    <>
    
    <Routes>
      {
        Publicelement.map((item)=>{
          return(
            <>
            <Route path={item.path} element={item.component}/>
            </>
          )
        })
      }

      {
        privaterouter.map((item)=>{
          return(
            <>
            <Route path={item.path} element={item.component}/>
            </>
          )
        })
      }


    </Routes>
    
    
    </>
  )
}

export default Routing